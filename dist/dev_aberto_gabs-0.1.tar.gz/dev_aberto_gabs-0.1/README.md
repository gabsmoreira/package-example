# package-example
Exemplo de pacote para Python

link para disciplina: https://github.com/Insper/dev-aberto